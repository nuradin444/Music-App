package com.example.user.mymusicapp;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.content.Intent;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    static String json = "";
    String searchQ = "";
    ArrayList<String> artistNames = new ArrayList<>();
    ArrayList<String> artistIDs = new ArrayList<>();

    ListView artists;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

      //sets out the search query to save any word typed to local storage
        SharedPreferences spref = getSharedPreferences("searchName", Context.MODE_PRIVATE);
        EditText mEdit = (EditText) findViewById(R.id.editText);
        mEdit.setText(spref.getString("Name", ""));


        artists = (ListView) findViewById(R.id.artistLst);

        artists.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                ArtistActivity.artistID = artistIDs.get(position);

                Log.i("artistID", ArtistActivity.artistID);

                Intent intent = new Intent(HomeActivity.this, ArtistActivity.class);
                startActivity(intent);
            }
        });

        try {
            JSONObject topFifty = new JSONObject(json);
            JSONObject artistsJson = topFifty.getJSONObject("artists"); // get data object
            JSONArray fiftyArr = artistsJson.getJSONArray("artist");

            for (int i = 0; i < fiftyArr.length(); i++) {

                JSONObject currentArtist = fiftyArr.getJSONObject(i);

                if (currentArtist != null) {
                    Log.i("name", currentArtist.getString("name"));
                    artistNames.add(currentArtist.getString("name"));
                    artistIDs.add(currentArtist.getString("mbid"));
                }

            }

            ListView artists = (ListView) findViewById(R.id.artistLst);
            ArrayAdapter<String> artistArrayAdapter = new ArrayAdapter<String>(HomeActivity.this, android.R.layout.simple_expandable_list_item_1, artistNames);
            artists.setAdapter(artistArrayAdapter);


            Log.i("artists", fiftyArr.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    Button mButton;
    EditText mEdit;


    public void searchBtnClick(View view) {

        ArrayAdapter<String> artistAdapter = new ArrayAdapter<String>(HomeActivity.this, android.R.layout.simple_expandable_list_item_1, artistNames);
        artistAdapter.clear();
        artistAdapter.notifyDataSetChanged();

        artistNames.clear();
        artistIDs.clear();



        Log.i("Button", "Clicked");

        EditText mEdit = (EditText) findViewById(R.id.editText);

        Log.v("EditText", mEdit.getText().toString());

        searchQ = mEdit.getText().toString();


        SharedPreferences spref = getSharedPreferences("searchName", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = spref.edit();
        editor.putString("Name", searchQ);
        editor.commit();

        Log.i("saved", spref.getString("Name", ""));

        Log.i("search Queary", searchQ);

        new AsyncTaskParseJson().execute();

        Log.i("Returned", json);

    }

    public void addPermissions(View view ){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] { Manifest.permission.ACCESS_FINE_LOCATION}, 10);
        }else{
            Intent i = new Intent(this, Music.class);

            startActivity(i);


        }

    }





    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 10:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // All good!
                } else {
                    Toast.makeText(this, "Need your location!", Toast.LENGTH_SHORT).show();
                }

                break;
        }
    }



    public class AsyncTaskParseJson extends AsyncTask<String, String, String> {

        // set the url of the web service to call
        String yourServiceUrl = "http://ws.audioscrobbler.com/2.0/?method=album.getinfo&api_key=560ad48037b67c8442e87cd1a5e77a9c&mbid=c559efc2-f734-41ae-93bd-2d78414e0356&format=json";


        @Override
        // this method is used for......................
        protected void onPreExecute() {
        }

        @Override
        // this method is used for...................
        protected String doInBackground(String... arg0) {
            try {
                // create new instance of the httpConnect class
                httpConnect jParser = new httpConnect();


                Log.i("*******", "pre json call ************************************************");
                // get json string from service url
                json = jParser.apiArtistSearch(searchQ);

                Log.i("Returned", json);

                JSONObject searchJson = new JSONObject(json);
                JSONObject artistsJson = searchJson.getJSONObject("results"); // get data object
                JSONObject matchesJson = artistsJson.getJSONObject("artistmatches");
                JSONArray resultsArray = matchesJson.getJSONArray("artist");

                for (int i = 0; i < resultsArray.length(); i++) {

                    JSONObject currentArtist = resultsArray.getJSONObject(i);

                    if (currentArtist != null) {
                        Log.i("name", currentArtist.getString("name"));
                        artistNames.add(currentArtist.getString("name"));
                        artistIDs.add(currentArtist.getString("mbid"));
                    }

                }


            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        // below method will run when service HTTP request is complete, will then bind tweet text in arrayList to ListView
        protected void onPostExecute(String strFromDoInBg) {
            HomeActivity.json = json;

            artists = (ListView) findViewById(R.id.artistLst);
            ArrayAdapter<String> artistAdapter = new ArrayAdapter<String>(HomeActivity.this, android.R.layout.simple_expandable_list_item_1, artistNames);
            artists.setAdapter(artistAdapter);


        }



        }
    }

