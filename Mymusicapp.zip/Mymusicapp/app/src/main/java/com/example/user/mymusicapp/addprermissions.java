package com.example.user.mymusicapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.Manifest;
import android.support.v4.app.ActivityCompat;

public class addprermissions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addprermissions);
    }

    public void cameraPermissions(View view){
        ActivityCompat.requestPermissions(addprermissions.this,
                new String[]{Manifest.permission.CAMERA},
                1);
    }
}
