package com.example.user.mymusicapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

// added asynctask class methods below -  you can make this class as a separate class file

public class Mymusicapp extends AppCompatActivity {

    ListView mListView;
    ArrayList<String> items = new ArrayList<>();
    public static String searchQ = "miracle";
    String json;


    private static int SPLASH_TIME_OUT = 4000;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mymusicapp);
        new AsyncTaskParseJson().execute();
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                Intent homeIntent = new Intent(Mymusicapp.this, HomeActivity.class);
                startActivity(homeIntent);
                finish();
            }


        }, SPLASH_TIME_OUT);
    }
    public class MainActivity extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_mymusicapp);
        }

        public void cameraIntent(View view) {
            int REQUEST_IMAGE_CAPTURE = 1;
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
            }
        }

        public void runPermissions(View view){
            Intent intent=new Intent(this, addprermissions.class);
            startActivity(intent);
        }
    }

    public void addPermissions(View view) {

        // create an intent to start the activity called userPermissions
        Intent intent = new Intent(this, userPermissions.class);
        // run Permissions activity
        startActivity(intent);
    }

    public class AsyncTaskParseJson extends AsyncTask<String, String, String> {

        // set the url of the web service to call
        String yourServiceUrl = "http://ws.audioscrobbler.com/2.0/?method=album.getinfo&api_key=560ad48037b67c8442e87cd1a5e77a9c&mbid=c559efc2-f734-41ae-93bd-2d78414e0356&format=json";



        @Override
        // this method is used for......................
        protected void onPreExecute() {}

        @Override
        // this method is used for...................
        protected String doInBackground(String... arg0)  {
            try {
                // create new instance of the httpConnect class
                httpConnect jParser = new httpConnect();


                Log.i("*******", "pre json call ************************************************" );
                // get json string from service url
                json = jParser.apiTopFifty();

                Log.i("Returned",json);

                // save returned json to your test string


            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        // below method will run when service HTTP request is complete, will then bind tweet text in arrayList to ListView
        protected void onPostExecute(String strFromDoInBg) {
            HomeActivity.json = json;
        }
    }

    /** Called when the user touches the Top 40 button */
    /*public void getMusicData(View view) {

        // create an intent to start Music activity
        // Intent intent = new Intent(this, Music.class);
        // startActivity(intent);

        mListView = (ListView) findViewById(R.id.list_view);
        ArrayList<String> namesLst = new ArrayList<>(Arrays.asList(Names));


        //CustomAdaptor customAdaptor =new CustomAdaptor();
        //mListView.setAdapter(customAdaptor);

        ArrayAdapter<String> artists = new ArrayAdapter<String>(Mymusicapp.this, android.R.layout.simple_list_item_1, namesLst);
        mListView.setAdapter(artists);

    }*/
    /*class CustomAdaptor extends BaseAdapter {
        @Override
        public int getCount() {
            return images.length();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View view =getLayoutInflater().inflate(R.layout.activity_music, null);

            ImageView mImageView = view.findViewById(R.id.imageView);
            TextView mTextView = (TextView) findViewById(R.id.textView);

            mImageView.setImageResource(images [position]);
            mTextView.setText(Names[position]);

            return view;
            ListView list = (ListView)findViewById(R.id.list_view);
            ArrayAdapter<String> tweetArrayAdapter = new ArrayAdapter<String>(Mymusicapp.this, android.R.layout.simple_expandable_list_item_1, items);
            list.setAdapter(tweetArrayAdapter);
        }
    }*/
}
