package com.example.user.mymusicapp;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URL;
import java.util.ArrayList;

public class ArtistActivity extends AppCompatActivity {

    static String artistID;
    static String json = "";
    static String artistName;
    static String artistSumm;
    //declaring the url for to get the image from the JSON
    static URL imgUrl;

    ImageView artistImg;
    TextView nameView;
    ListView summView;

    ArrayList<String> bioLst = new ArrayList<String>();
    ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artist);


        artistImg = (ImageView) findViewById(R.id.artistImgView);
        nameView = (TextView) findViewById(R.id.nameTxtView);
        summView = (ListView) findViewById(R.id.artistBioView);


        new ArtistActivity.AsyncTaskParseJson().execute();
    }

    public class AsyncTaskParseJson extends AsyncTask<String, String, String> {

        // set the url of the web service to call
        String yourServiceUrl = "http://ws.audioscrobbler.com/2.0/?method=album.getinfo&api_key=560ad48037b67c8442e87cd1a5e77a9c&mbid=c559efc2-f734-41ae-93bd-2d78414e0356&format=json";


        @Override
        // this method is used for......................
        protected void onPreExecute() {
        }

        @Override
        // this method is used for...................
        protected String doInBackground(String... arg0) {
            try {
                // a new one the the httpconnect
                httpConnect jParser = new httpConnect();


                Log.i("*******", "pre json call ************************************************");
                // get json string from service url
                json = jParser.apiArtistInfo(artistID);

                Log.i("Returned", json);

                JSONObject searchJson = new JSONObject(json);
                JSONObject artistsJson = searchJson.getJSONObject("artist");    // Name
                JSONArray imageArr = artistsJson.getJSONArray("image");          // ImageUrl
                JSONObject bio = artistsJson.getJSONObject("bio");            // Bio
                artistSumm = bio.getString("summary");

                JSONObject image = imageArr.getJSONObject(3);

                imgUrl = new URL(image.getString("#text"));

                Log.i("name", artistsJson.getString("name"));
                artistName = artistsJson.getString("name");

                Log.i("bio", artistSumm);


            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        // below method will run when service HTTP request is complete, will then bind tweet text in arrayList to ListView
        protected void onPostExecute(String strFromDoInBg) {
           //uses the text to display the artists name
            nameView.setText(artistName);

            //uses this to display the bio about the artist
            bioLst.add(artistSumm);

            adapter=new ArrayAdapter(ArtistActivity.this, android.R.layout.simple_list_item_1, bioLst);
            summView.setAdapter(adapter);
            //this is used to load the image into the image
            Picasso.with(getApplicationContext()).load(imgUrl.toString()).into(artistImg);
        }



    }
}

