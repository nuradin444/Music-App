package com.example.user.mymusicapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.os.AsyncTask;
import android.widget.*;
import java.io.InputStream;
import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.util.HashMap;
import java.util.List;
import android.widget.SimpleAdapter;
import android.support.v7.app.AppCompatActivity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;

public class Music extends AppCompatActivity {
    // global vsariable to store returned xml data from service
    static String xml = "";

    // global variable to bitmap for current number 1 single (we aren't returning the other 39 songs!)
    static Bitmap bitmap;

    // array list to store song names from  service
    ArrayList<String> songs = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // create a new TextView widget programmatically

        TextView tv1 = new TextView(this);
        tv1.setTextSize(40);
        setContentView(tv1);

        // get location code
        // you should probably handle checking if permissions are granted!

        // acquire a reference to the system Location Manager
        LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        // Use GPS provider to get last known location
        String locationProvider = LocationManager.GPS_PROVIDER;
        Location lastKnownLocation = locationManager.getLastKnownLocation(locationProvider);

        // create a few new variable to get and store the lat/long coordinates of last known location
        double lat = lastKnownLocation.getLatitude();
        double longi = lastKnownLocation.getLongitude();

        // bind the lat long coordinates to the programmatically created TextView for displaying
        tv1.setText("Location:\n" + lat +"\n" + longi);
    }

}
